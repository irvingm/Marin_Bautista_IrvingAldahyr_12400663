package ittepic.edu.mx.firebase;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by irvin on 16/04/2018.
 */

public class ProfileActivity extends AppCompatActivity {

    private TextView tvEmail;

    EditText mensaje, control;
    String men, cont;
    Button guardar;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    DatabaseReference mensajeref = databaseReference.child("Nombre");
    DatabaseReference controlref = databaseReference.child("Control");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        tvEmail = (TextView) findViewById(R.id.tvEmailProfile);
        tvEmail.setText(getIntent().getExtras().getString("Email"));

        mensaje = findViewById(R.id.editText);
        control = findViewById(R.id.editText1);
        guardar = findViewById(R.id.button2);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                men = mensaje.getText().toString();
                mensajeref.setValue(men);
                cont = control.getText().toString();
                controlref.setValue(cont);
            }
        });


    }


    protected void onStart(){
        super.onStart();
    }
}

